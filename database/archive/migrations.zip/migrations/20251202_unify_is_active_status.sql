-- =====================================================
-- Migration: Unify is_active status across all tables
-- Date: 2025-12-02
-- Author: Claude (AI Assistant)
--
-- Purpose: Replace is_archived/is_deleted boolean columns
--          with unified is_active INTEGER status:
--          0 = inactive
--          1 = active (default)
--          3 = archive
--          4 = deleted (soft delete)
--
-- DOES NOT TOUCH:
--   - refresh_tokens.is_revoked (token security)
--   - oauth_tokens.revoked (token security)
-- =====================================================

BEGIN;

-- =====================================================
-- PHASE 1: Tables with BOTH is_active AND is_archived
-- (users, departments, teams, areas)
-- =====================================================

-- 1.1 USERS: Migrate is_archived → is_active = 3
UPDATE users
SET is_active = 3
WHERE is_archived = true AND is_active = 1;

-- Drop archived_at and is_archived
ALTER TABLE users DROP COLUMN IF EXISTS archived_at;
ALTER TABLE users DROP COLUMN IF EXISTS is_archived;

-- 1.2 DEPARTMENTS: Migrate is_archived → is_active = 3
UPDATE departments
SET is_active = 3
WHERE is_archived = true AND is_active = 1;

ALTER TABLE departments DROP COLUMN IF EXISTS is_archived;

-- 1.3 TEAMS: Migrate is_archived → is_active = 3
UPDATE teams
SET is_active = 3
WHERE is_archived = true AND is_active = 1;

ALTER TABLE teams DROP COLUMN IF EXISTS is_archived;

-- 1.4 AREAS: Migrate is_archived → is_active = 3
UPDATE areas
SET is_active = 3
WHERE is_archived = true AND is_active = 1;

ALTER TABLE areas DROP COLUMN IF EXISTS is_archived;

-- =====================================================
-- PHASE 2: Tables with ONLY is_archived (no is_active)
-- (documents, chat_channels)
-- =====================================================

-- 2.1 DOCUMENTS: Add is_active, migrate, drop is_archived
ALTER TABLE documents
ADD COLUMN IF NOT EXISTS is_active SMALLINT DEFAULT 1;

UPDATE documents
SET is_active = 3
WHERE is_archived = true;

UPDATE documents
SET is_active = 1
WHERE is_active IS NULL;

ALTER TABLE documents DROP COLUMN IF EXISTS archived_at;
ALTER TABLE documents DROP COLUMN IF EXISTS is_archived;

-- 2.2 CHAT_CHANNELS: Add is_active, migrate, drop is_archived
ALTER TABLE chat_channels
ADD COLUMN IF NOT EXISTS is_active SMALLINT DEFAULT 1;

UPDATE chat_channels
SET is_active = 3
WHERE is_archived = true;

UPDATE chat_channels
SET is_active = 1
WHERE is_active IS NULL;

ALTER TABLE chat_channels DROP COLUMN IF EXISTS archived_at;
ALTER TABLE chat_channels DROP COLUMN IF EXISTS is_archived;

-- =====================================================
-- PHASE 3: Tables with is_deleted
-- (chat_messages)
-- =====================================================

-- 3.1 CHAT_MESSAGES: Add is_active, migrate is_deleted → is_active = 4
ALTER TABLE chat_messages
ADD COLUMN IF NOT EXISTS is_active SMALLINT DEFAULT 1;

UPDATE chat_messages
SET is_active = 4
WHERE is_deleted = true;

UPDATE chat_messages
SET is_active = 1
WHERE is_active IS NULL;

ALTER TABLE chat_messages DROP COLUMN IF EXISTS deleted_at;
ALTER TABLE chat_messages DROP COLUMN IF EXISTS is_deleted;

-- =====================================================
-- PHASE 4: Create indexes for performance
-- =====================================================

CREATE INDEX IF NOT EXISTS idx_users_is_active ON users(is_active);
CREATE INDEX IF NOT EXISTS idx_departments_is_active ON departments(is_active);
CREATE INDEX IF NOT EXISTS idx_teams_is_active ON teams(is_active);
CREATE INDEX IF NOT EXISTS idx_areas_is_active ON areas(is_active);
CREATE INDEX IF NOT EXISTS idx_documents_is_active ON documents(is_active);
CREATE INDEX IF NOT EXISTS idx_chat_channels_is_active ON chat_channels(is_active);
CREATE INDEX IF NOT EXISTS idx_chat_messages_is_active ON chat_messages(is_active);

-- =====================================================
-- PHASE 5: Add comments for documentation
-- =====================================================

COMMENT ON COLUMN users.is_active IS 'Status: 0=inactive, 1=active, 3=archived, 4=deleted';
COMMENT ON COLUMN departments.is_active IS 'Status: 0=inactive, 1=active, 3=archived, 4=deleted';
COMMENT ON COLUMN teams.is_active IS 'Status: 0=inactive, 1=active, 3=archived, 4=deleted';
COMMENT ON COLUMN areas.is_active IS 'Status: 0=inactive, 1=active, 3=archived, 4=deleted';
COMMENT ON COLUMN documents.is_active IS 'Status: 0=inactive, 1=active, 3=archived, 4=deleted';
COMMENT ON COLUMN chat_channels.is_active IS 'Status: 0=inactive, 1=active, 3=archived, 4=deleted';
COMMENT ON COLUMN chat_messages.is_active IS 'Status: 0=inactive, 1=active, 3=archived, 4=deleted';

COMMIT;

-- =====================================================
-- VERIFICATION QUERIES (run after migration)
-- =====================================================
-- SELECT table_name, column_name FROM information_schema.columns
-- WHERE table_schema = 'public'
-- AND (column_name LIKE '%archived%' OR column_name LIKE '%deleted%')
-- AND table_name NOT IN ('archived_tenant_invoices', 'deletion_audit_trail', 'tenant_deletion_log', 'tenant_deletion_queue');
--
-- Expected: Empty result (no more is_archived/is_deleted columns)
