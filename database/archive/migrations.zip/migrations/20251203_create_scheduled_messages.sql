-- =====================================================
-- Migration: Create Scheduled Messages Table
-- Date: 2025-12-03
-- Author: Claude
-- Description: Table for storing scheduled chat messages
--              that will be sent at a future time
-- =====================================================

-- 1. Create scheduled_messages table
CREATE TABLE IF NOT EXISTS scheduled_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    sender_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    attachment_path VARCHAR(500),
    attachment_name VARCHAR(255),
    attachment_type VARCHAR(100),
    attachment_size INTEGER,
    scheduled_for TIMESTAMPTZ NOT NULL,
    is_active SMALLINT DEFAULT 1,  -- 0=cancelled, 1=pending, 4=sent (consistent with app)
    created_at TIMESTAMPTZ DEFAULT NOW(),
    sent_at TIMESTAMPTZ,

    -- Constraint: scheduled_for must be in the future (at creation)
    -- Note: This is enforced at application level for flexibility
    CONSTRAINT chk_content_not_empty CHECK (content <> '')
);

-- 2. Create Indexes
-- Partial index for pending messages (used by worker)
CREATE INDEX IF NOT EXISTS idx_scheduled_pending
ON scheduled_messages (scheduled_for)
WHERE is_active = 1;

-- Index for user's scheduled messages
CREATE INDEX IF NOT EXISTS idx_scheduled_sender
ON scheduled_messages (sender_id, is_active);

-- Index for conversation's scheduled messages
CREATE INDEX IF NOT EXISTS idx_scheduled_conversation
ON scheduled_messages (conversation_id, is_active);

-- Tenant index for RLS
CREATE INDEX IF NOT EXISTS idx_scheduled_tenant
ON scheduled_messages (tenant_id);

-- 3. Enable Row Level Security
ALTER TABLE scheduled_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE scheduled_messages FORCE ROW LEVEL SECURITY;

-- 4. Create RLS Policy (tenant isolation)
-- NOTE: WITH CHECK is required for INSERT operations!
DROP POLICY IF EXISTS tenant_isolation ON scheduled_messages;
CREATE POLICY tenant_isolation ON scheduled_messages
    FOR ALL
    USING (
        -- Root/Admin access (no tenant context)
        current_setting('app.tenant_id', true) IS NULL
        -- Or matching tenant
        OR tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::integer
    )
    WITH CHECK (
        -- Same conditions for INSERT/UPDATE
        current_setting('app.tenant_id', true) IS NULL
        OR tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::integer
    );

-- 5. Grant Permissions to app_user
GRANT SELECT, INSERT, UPDATE, DELETE ON scheduled_messages TO app_user;

-- 6. Add comment for documentation
COMMENT ON TABLE scheduled_messages IS 'Stores chat messages scheduled to be sent at a future time';
COMMENT ON COLUMN scheduled_messages.is_active IS '0=cancelled, 1=pending, 4=sent (soft delete pattern)';
COMMENT ON COLUMN scheduled_messages.scheduled_for IS 'UTC timestamp when message should be sent';

-- =====================================================
-- Verification Queries (run manually after migration)
-- =====================================================
-- \d scheduled_messages
-- SELECT * FROM pg_policies WHERE tablename = 'scheduled_messages';
-- SELECT indexname FROM pg_indexes WHERE tablename = 'scheduled_messages';
