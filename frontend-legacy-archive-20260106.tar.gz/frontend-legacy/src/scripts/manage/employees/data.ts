/**
 * Employee Management - Data Layer
 * API calls, state management, and employee operations
 */

import { ApiClient } from '../../../utils/api-client';
import { $$id } from '../../../utils/dom-utils';
import { showErrorAlert } from '../../utils/alerts';
import type { Employee, IEmployeesManager, WindowWithEmployeeHandlers } from './types';
import { processFormField, getMultiSelectValues } from './ui';

// ===== CONSTANTS =====
// NOTE: Employee assignment simplified - ONLY teamIds
// Area/Department are inherited from Team automatically
const EMPLOYEE_FORM_ELEMENT_IDS = {
  TEAMS_SELECT: 'employee-teams',
  // NOTE: Removed - Employees don't have area/dept/fullAccess assignments
  // AREAS_SELECT: 'employee-areas',
  // DEPARTMENTS_SELECT: 'employee-departments',
  // FULL_ACCESS_TOGGLE: 'employee-full-access',
} as const;

// NOTE: DISABLED_OPACITY_CLASS removed - no longer needed after form simplification

// ===== GLOBAL STATE =====
// Note: employeesManager will be set from index.ts to avoid circular dependencies
let employeesManager: IEmployeesManager | null = null;

// State getter/setter (needed for import safety)
export function getEmployeesManager(): IEmployeesManager | null {
  return employeesManager;
}

export function setEmployeesManager(manager: IEmployeesManager): void {
  employeesManager = manager;
}

// ===== API CLIENT =====
export const apiClient = ApiClient.getInstance();

// ===== FORM DATA PROCESSING =====

/**
 * Validate password on form submit
 * Must match backend PasswordSchema: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/
 * Exported for use in forms.ts (live validation)
 */
export function validatePasswordOnSubmit(password: string): { valid: boolean; message: string } {
  // Check length
  if (password.length > 0 && password.length < 8) {
    return { valid: false, message: 'Passwort muss mindestens 8 Zeichen lang sein!' };
  }

  // Check complexity
  if (password.length > 0) {
    const hasLowercase = /[a-z]/.test(password);
    const hasUppercase = /[A-Z]/.test(password);
    const hasNumber = /\d/.test(password);

    if (!hasLowercase || !hasUppercase || !hasNumber) {
      return {
        valid: false,
        message: 'Passwort muss mindestens einen Großbuchstaben, einen Kleinbuchstaben und eine Zahl enthalten!',
      };
    }
  }

  return { valid: true, message: '' };
}

/**
 * Extract form data into a typed record object
 * @param form - The form element to extract data from
 * @param isUpdate - Whether this is an update (true) or create (false) operation
 */
function extractFormDataToRecord(form: HTMLFormElement, isUpdate: boolean): Record<string, unknown> {
  const formData = new FormData(form);
  const data: Record<string, unknown> = {};

  formData.forEach((value, key) => {
    if (typeof value === 'string') {
      processFormField(data, key, value, isUpdate);
    }
  });

  // Special handling: if availabilityStatus is 'available', set dates to null
  if (data['availabilityStatus'] === 'available') {
    data['availabilityStart'] = null;
    data['availabilityEnd'] = null;
  }

  return data;
}

/**
 * Validate required employee fields
 */
function validateRequiredEmployeeFields(data: Record<string, unknown>): { valid: boolean; message?: string } {
  if (
    typeof data['email'] !== 'string' ||
    data['email'].length === 0 ||
    typeof data['firstName'] !== 'string' ||
    data['firstName'].length === 0 ||
    typeof data['lastName'] !== 'string' ||
    data['lastName'].length === 0
  ) {
    return { valid: false, message: 'Bitte füllen Sie alle Pflichtfelder aus' };
  }
  return { valid: true };
}

/**
 * Validate employee password if provided
 */
function validateEmployeePasswordField(data: Record<string, unknown>): { valid: boolean; message?: string } {
  if (typeof data['password'] === 'string' && data['password'] !== '') {
    const passwordValidation = validatePasswordOnSubmit(data['password']);
    if (!passwordValidation.valid) {
      return { valid: false, message: passwordValidation.message };
    }
  }
  return { valid: true };
}

/**
 * Generate a valid username from an email address
 * - Takes the part before @
 * - Replaces invalid characters with underscores
 * - Only allows letters, numbers, underscores, and hyphens
 * @param email - Email address to convert
 * @returns Valid username
 */
function generateUsernameFromEmail(email: string): string {
  // Take the part before @ (local part of email)
  const localPart = email.split('@')[0] ?? email;

  // Replace any character that's not a letter, number, underscore, or hyphen with underscore
  // This ensures the username matches the backend regex: /^[\w-]+$/
  return localPart.replace(/[^\w-]/g, '_');
}

/**
 * Prepare employee data for save operation
 * SIMPLIFIED: Employees ONLY get teamIds - Area/Department inherited from Team
 */
function prepareEmployeeDataForSave(data: Record<string, unknown>): void {
  data['role'] = 'employee';
  data['username'] = typeof data['email'] === 'string' ? generateUsernameFromEmail(data['email']) : data['email'];
  if (data['isActive'] !== undefined) {
    data['isActive'] = data['isActive'] === '1' || data['isActive'] === true;
  }

  // SIMPLIFIED: Only teamIds for employees
  // Area/Department are inherited from Team automatically
  const teamIds = getMultiSelectValues(EMPLOYEE_FORM_ELEMENT_IDS.TEAMS_SELECT);
  data['teamIds'] = teamIds;

  // NOTE: Removed areaIds, departmentIds, hasFullAccess - Employees don't use these
  // They get Area/Department access via Team membership inheritance

  console.info('[prepareEmployeeDataForSave] Employee teams:', { teamIds: data['teamIds'] });
}

// ===== SAVE OPERATIONS =====

/**
 * Perform employee save operation and close modal
 */
async function performEmployeeSave(data: Record<string, unknown>, form: HTMLFormElement): Promise<void> {
  console.info('[saveEmployee] Starting save operation...');

  if (employeesManager?.currentEmployeeId !== null && employeesManager?.currentEmployeeId !== undefined) {
    console.info('[saveEmployee] Updating employee ID:', employeesManager.currentEmployeeId);
    await employeesManager.updateEmployee(employeesManager.currentEmployeeId, data as Partial<Employee>);
  } else {
    console.info('[saveEmployee] Creating new employee...');
    await employeesManager?.createEmployee(data as Partial<Employee>);
  }

  console.info('[saveEmployee] Save successful, closing modal...');
  const w = window as WindowWithEmployeeHandlers;
  w.hideEmployeeModal?.();
  form.reset();

  if (employeesManager !== null) {
    employeesManager.currentEmployeeId = null;
  }
}

/**
 * Save employee handler - orchestrates the save workflow
 */
export async function handleSaveEmployee(): Promise<void> {
  console.info('[saveEmployee] Function called');
  const form = $$id('employee-form');
  if (!(form instanceof HTMLFormElement)) {
    console.error('[saveEmployee] Form not found or not a form element');
    return;
  }
  console.info('[saveEmployee] Form found, processing data...');

  const isUpdate = employeesManager?.currentEmployeeId !== null && employeesManager?.currentEmployeeId !== undefined;
  const data = extractFormDataToRecord(form, isUpdate);

  const requiredValidation = validateRequiredEmployeeFields(data);
  if (!requiredValidation.valid) {
    showErrorAlert(requiredValidation.message ?? 'Validation error');
    return;
  }

  const passwordValidation = validateEmployeePasswordField(data);
  if (!passwordValidation.valid) {
    showErrorAlert(passwordValidation.message ?? 'Password validation error');
    return;
  }

  prepareEmployeeDataForSave(data);

  try {
    await performEmployeeSave(data, form);
  } catch (error) {
    console.error('Error saving employee:', error);
    employeesManager?.handleEmployeeSaveError(error);
  }
}

// ===== MULTI-SELECT LOADING (SIMPLIFIED - ONLY TEAMS) =====

// NOTE: handleLoadAreas and handleLoadDepartments removed - Employees only get teams

/**
 * Handle loading teams for employee multi-select
 * SIMPLIFIED: This is the ONLY assignment for employees
 * Area/Department are inherited from the Team automatically
 */
export async function handleLoadTeams(): Promise<void> {
  const teams = await employeesManager?.loadTeams();
  const teamSelect = $$id(EMPLOYEE_FORM_ELEMENT_IDS.TEAMS_SELECT) as HTMLSelectElement | null;

  if (teamSelect !== null && teams !== undefined) {
    teamSelect.innerHTML = '';

    // Load all teams for employee assignment
    teams.forEach((team) => {
      const option = document.createElement('option');
      option.value = team.id.toString();
      // Show team name with department for context
      option.textContent = team.departmentName !== undefined ? `${team.name} (${team.departmentName})` : team.name;
      teamSelect.append(option);
    });

    console.info('[EmployeesManager] Loaded teams for employee select:', teams.length);
  }
}

// NOTE: All full access and area/department filter functions have been REMOVED
// Employees ONLY get team assignments - Area/Department are inherited from Team
// Removed functions:
// - disableAndClearSelect
// - applyFullAccessEnabledState
// - applyFullAccessDisabledState
// - setupFullAccessToggle
// - filterDepartmentsBySelectedAreas
// - getDepartmentsCoveredByAreas
// - filterTeamsBySelectedDepartmentsAndAreas
// - setupAreaDepartmentFilter
// - setupDepartmentTeamFilter
