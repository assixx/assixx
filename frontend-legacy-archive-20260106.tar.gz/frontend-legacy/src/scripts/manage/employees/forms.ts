/**
 * Employee Management Forms Layer - Modal and Form Handling
 * Following manage-admins pattern for consistent architecture
 */

import { $$id, setSafeHTML } from '../../../utils/dom-utils';
import { resetAndReinitializePasswordToggles } from '../../../utils/password-toggle';
import { setupPasswordStrength, resetPasswordStrengthUI } from '../../../utils/password-strength-integration';
import { showErrorAlert } from '../../utils/alerts';
import type { Employee, WindowWithEmployeeHandlers } from './types';
import {
  fillBasicFormFields,
  fillOptionalFormFields,
  fillAvailabilityFields,
  setStatusAndClearPasswords,
  setMultiSelectValues,
} from './ui';
import {
  getEmployeesManager,
  handleSaveEmployee,
  // NOTE: handleLoadAreas, handleLoadDepartments removed - Employees only get teams
  handleLoadTeams,
  // NOTE: setupFullAccessToggle, filterDepartmentsBySelectedAreas, filterTeamsBySelectedDepartmentsAndAreas removed
} from './data';

// ===== CONSTANTS =====
const MODAL_ACTIVE_CLASS = 'modal-overlay--active';

// Field state classes for validation feedback (Design System)
const FIELD_STATE_ERROR = 'is-error';
const FIELD_STATE_SUCCESS = 'is-success';

// CSS class for disabled state visual feedback
// NOTE: DISABLED_OPACITY_CLASS removed - not needed after form simplification

// Password toggle cleanup controller (prevent memory leaks)
let passwordToggleCleanup: AbortController | null = null;

// ===== DOM ELEMENT SELECTORS =====
// NOTE: IDs without '#' prefix because $$id() adds it automatically
export const SELECTORS = {
  EMPLOYEE_MODAL: 'employee-modal',
  MODAL_TITLE: 'employee-modal-title',
  EMPLOYEE_FORM: 'employee-form',
  EMPLOYEE_ID: 'employee-id',
  DELETE_MODAL: 'delete-employee-modal',
  DELETE_INPUT: 'delete-employee-id',
  POSITION_TRIGGER: 'position-trigger',
  POSITION_INPUT: 'employee-position',
  STATUS_TRIGGER: 'status-trigger',
  STATUS_INPUT: 'employee-status',
  AVAILABILITY_TRIGGER: 'availability-status-trigger',
  AVAILABILITY_INPUT: 'availability-status',
  // Validation selectors (with # prefix for $$() compatibility)
  EMPLOYEE_EMAIL: '#employee-email',
  EMPLOYEE_EMAIL_CONFIRM: '#employee-email-confirm',
  EMPLOYEE_PASSWORD: '#employee-password',
  EMPLOYEE_PASSWORD_CONFIRM: '#employee-password-confirm',
  EMAIL_ERROR: '#email-error',
  PASSWORD_ERROR: '#password-error',
} as const;

// ===== HELPER FUNCTIONS =====

// NOTE: applyFullAccessDisabledState removed - Employees don't have fullAccess toggle anymore
// Employees ONLY get Team assignments (Area/Department inherited from Team)

/**
 * Reset a single dropdown to default state
 */
function resetDropdown(triggerId: string, inputId: string, defaultText: string | null, defaultValue: string): void {
  const trigger = $$id(triggerId);
  const input = $$id(inputId) as HTMLInputElement | null;

  if (trigger !== null) {
    const span = trigger.querySelector('span');
    if (span !== null && defaultText !== null) {
      if (defaultText.includes('<span')) {
        // HTML content (for status badges)
        setSafeHTML(span, defaultText);
      } else {
        // Plain text
        span.textContent = defaultText;
      }
    }
  }

  if (input !== null) {
    input.value = defaultValue;
  }
}

/**
 * Reset custom dropdown displays to default values
 * SIMPLIFIED: Only team multi-select for employees
 */
export function resetCustomDropdowns(): void {
  // Reset Position Dropdown
  resetDropdown('position-trigger', 'employee-position', 'Bitte wählen...', '');

  // Reset Status Dropdown - default to "Aktiv"
  resetDropdown('status-trigger', 'employee-status', '<span class="badge badge--success">Aktiv</span>', '1');

  // Reset Availability Status Dropdown - default to "Verfügbar"
  resetDropdown('availability-status-trigger', 'availability-status', 'Verfügbar', 'available');

  // SIMPLIFIED: Only team multi-select for employees
  const teamSelect = $$id('employee-teams') as HTMLSelectElement | null;

  // Clear team multi-select
  if (teamSelect !== null) {
    Array.from(teamSelect.options).forEach((opt) => (opt.selected = false));
    teamSelect.disabled = false;
  }

  // NOTE: Removed area/department/fullAccess reset - Employees don't use these anymore
}

/**
 * Clear all form validation states
 */
export function clearFieldValidationStates(): void {
  const emailField = document.querySelector(SELECTORS.EMPLOYEE_EMAIL);
  const emailConfirmField = document.querySelector(SELECTORS.EMPLOYEE_EMAIL_CONFIRM);
  const passwordField = document.querySelector(SELECTORS.EMPLOYEE_PASSWORD);
  const passwordConfirmField = document.querySelector(SELECTORS.EMPLOYEE_PASSWORD_CONFIRM);

  // Remove validation classes
  emailField?.classList.remove(FIELD_STATE_ERROR, FIELD_STATE_SUCCESS);
  emailConfirmField?.classList.remove(FIELD_STATE_ERROR, FIELD_STATE_SUCCESS);
  passwordField?.classList.remove(FIELD_STATE_ERROR, FIELD_STATE_SUCCESS);
  passwordConfirmField?.classList.remove(FIELD_STATE_ERROR, FIELD_STATE_SUCCESS);

  // Hide error messages
  document.querySelector(SELECTORS.EMAIL_ERROR)?.classList.add('u-hidden');
  document.querySelector(SELECTORS.PASSWORD_ERROR)?.classList.add('u-hidden');
}

/**
 * Setup live email validation with visual feedback
 * Following manage-root pattern
 */
function setupEmailValidation(): void {
  const emailField = document.querySelector<HTMLInputElement>(SELECTORS.EMPLOYEE_EMAIL);
  const emailConfirmField = document.querySelector<HTMLInputElement>(SELECTORS.EMPLOYEE_EMAIL_CONFIRM);
  const emailError = document.querySelector(SELECTORS.EMAIL_ERROR);

  if (emailField !== null && emailConfirmField !== null && emailError !== null) {
    const validateEmails = (): void => {
      const email = emailField.value;
      const emailConfirm = emailConfirmField.value;

      if (emailConfirm !== '') {
        if (email !== emailConfirm) {
          // Mismatch: Show error state
          emailError.classList.remove('u-hidden');
          emailField.classList.add(FIELD_STATE_ERROR);
          emailField.classList.remove(FIELD_STATE_SUCCESS);
          emailConfirmField.classList.add(FIELD_STATE_ERROR);
          emailConfirmField.classList.remove(FIELD_STATE_SUCCESS);
        } else {
          // Match: Show success state
          emailError.classList.add('u-hidden');
          emailField.classList.remove(FIELD_STATE_ERROR);
          emailField.classList.add(FIELD_STATE_SUCCESS);
          emailConfirmField.classList.remove(FIELD_STATE_ERROR);
          emailConfirmField.classList.add(FIELD_STATE_SUCCESS);
        }
      } else {
        // Neutral: Clear all states
        emailError.classList.add('u-hidden');
        emailField.classList.remove(FIELD_STATE_ERROR, FIELD_STATE_SUCCESS);
        emailConfirmField.classList.remove(FIELD_STATE_ERROR, FIELD_STATE_SUCCESS);
      }
    };

    // Live validation on input
    emailField.addEventListener('input', validateEmails);
    emailConfirmField.addEventListener('input', validateEmails);
  }
}

/**
 * Setup live password validation with visual feedback
 * Following manage-root pattern
 */
function setupPasswordValidation(): void {
  const passwordField = document.querySelector<HTMLInputElement>(SELECTORS.EMPLOYEE_PASSWORD);
  const passwordConfirmField = document.querySelector<HTMLInputElement>(SELECTORS.EMPLOYEE_PASSWORD_CONFIRM);
  const passwordError = document.querySelector(SELECTORS.PASSWORD_ERROR);

  if (passwordField !== null && passwordConfirmField !== null && passwordError !== null) {
    const validatePasswords = (): void => {
      const password = passwordField.value;
      const passwordConfirm = passwordConfirmField.value;

      if (passwordConfirm !== '') {
        const passwordsMatch = password.length === passwordConfirm.length && password === passwordConfirm;
        if (!passwordsMatch) {
          // Mismatch: Show error state
          passwordError.classList.remove('u-hidden');
          passwordField.classList.add(FIELD_STATE_ERROR);
          passwordField.classList.remove(FIELD_STATE_SUCCESS);
          passwordConfirmField.classList.add(FIELD_STATE_ERROR);
          passwordConfirmField.classList.remove(FIELD_STATE_SUCCESS);
        } else {
          // Match: Show success state
          passwordError.classList.add('u-hidden');
          passwordField.classList.remove(FIELD_STATE_ERROR);
          passwordField.classList.add(FIELD_STATE_SUCCESS);
          passwordConfirmField.classList.remove(FIELD_STATE_ERROR);
          passwordConfirmField.classList.add(FIELD_STATE_SUCCESS);
        }
      } else {
        // Neutral: Clear all states
        passwordError.classList.add('u-hidden');
        passwordField.classList.remove(FIELD_STATE_ERROR, FIELD_STATE_SUCCESS);
        passwordConfirmField.classList.remove(FIELD_STATE_ERROR, FIELD_STATE_SUCCESS);
      }
    };

    // Live validation on input
    passwordField.addEventListener('input', validatePasswords);
    passwordConfirmField.addEventListener('input', validatePasswords);
  }
}

/**
 * Initialize validation listeners for email and password fields
 * Call this on page load to enable live validation
 */
export function setupValidationListeners(): void {
  setupEmailValidation();
  setupPasswordValidation();
}

// ===== SUBMIT-TIME VALIDATION =====
// Note: validatePasswordOnSubmit moved to data.ts to avoid circular dependency

// N:M REFACTORING: Removed updateDropdownTriggerText and restoreDropdownValue
// These functions were for custom dropdowns, now using native multi-selects

// ===== MODAL FUNCTIONS =====

/**
 * Show employee modal for creating new employee
 * Following manage-admins showAddAdminModal pattern
 */
export function showAddEmployeeModal(): void {
  console.info('[showAddEmployeeModal] Opening modal for new employee');

  const modal = $$id(SELECTORS.EMPLOYEE_MODAL);
  const title = $$id(SELECTORS.MODAL_TITLE);
  const form = $$id(SELECTORS.EMPLOYEE_FORM) as HTMLFormElement | null;

  if (title !== null) {
    title.textContent = 'Neuen Mitarbeiter anlegen';
  }

  // Reset form
  if (form !== null) {
    form.reset();
  }

  // Reset custom dropdowns
  resetCustomDropdowns();

  // Hide availability section for new employees
  const availabilitySections = modal?.querySelectorAll('.form-section');
  availabilitySections?.forEach((section) => {
    const heading = section.querySelector('h4');
    if (heading !== null && heading.textContent === 'Verfügbarkeit') {
      (section as HTMLElement).style.display = 'none';
    }
  });

  // Hide status dropdown for CREATE (new employees are always active)
  const statusFieldGroup = document.querySelector('#status-field-group');
  statusFieldGroup?.classList.add('u-hidden');

  // Initialize password toggles
  passwordToggleCleanup = resetAndReinitializePasswordToggles(
    [
      { input: '#employee-password', toggle: '#employee-password-toggle' },
      { input: '#employee-password-confirm', toggle: '#employee-password-confirm-toggle' },
    ],
    passwordToggleCleanup,
  );

  // Setup password strength validation
  setupPasswordStrength({
    passwordFieldId: 'employee-password',
    strengthContainerId: 'employee-password-strength-container',
    strengthBarId: 'employee-password-strength-bar',
    strengthLabelId: 'employee-password-strength-label',
    strengthTimeId: 'employee-password-strength-time',
    feedbackContainerId: 'employee-password-feedback',
    feedbackWarningId: 'employee-password-feedback-warning',
    feedbackSuggestionsId: 'employee-password-feedback-suggestions',
    getUserInputs: () => {
      const firstName = ($$id('employee-first-name') as HTMLInputElement | null)?.value ?? '';
      const lastName = ($$id('employee-last-name') as HTMLInputElement | null)?.value ?? '';
      const email = ($$id('employee-email') as HTMLInputElement | null)?.value ?? '';
      return [firstName, lastName, email].filter((v) => v !== '');
    },
  });

  // Show modal
  if (modal !== null) {
    modal.classList.add(MODAL_ACTIVE_CLASS);
  }

  // NOTE: setupFullAccessToggle removed - Employees don't have fullAccess anymore

  // SIMPLIFIED: Load only teams for employees
  setTimeout(() => {
    const w = window as WindowWithEmployeeHandlers;
    void (async () => {
      // Load teams only (Areas/Departments are inherited from Team)
      await w.loadTeamsForEmployeeSelect?.();
      // NOTE: Removed area/department loading and filtering
    })();
  }, 100);
}

/**
 * Show employee modal for editing existing employee
 * Following manage-admins showEditAdminModal pattern
 * N:M REFACTORING: Updated to handle multi-select for departments/teams
 */

export function showEditEmployeeModal(employee: Employee, _departmentIds?: number[], teamIds?: number[]): void {
  // NOTE: departmentIds parameter kept for backwards compatibility but not used anymore
  console.info('[showEditEmployeeModal] Opening modal for employee:', employee.id);

  const modal = $$id(SELECTORS.EMPLOYEE_MODAL);
  const title = $$id(SELECTORS.MODAL_TITLE);

  if (title !== null) {
    title.textContent = 'Mitarbeiter bearbeiten';
  }

  // Fill form fields
  fillBasicFormFields(employee);
  fillOptionalFormFields(employee);
  fillAvailabilityFields(employee);
  setStatusAndClearPasswords(employee);

  // Show availability section for edit mode
  const availabilitySections = modal?.querySelectorAll('.form-section');
  availabilitySections?.forEach((section) => {
    const heading = section.querySelector('h4');
    if (heading !== null && heading.textContent === 'Verfügbarkeit') {
      (section as HTMLElement).style.display = 'block';
    }
  });

  // Show status dropdown for EDIT (allows changing status)
  const statusFieldGroup = document.querySelector('#status-field-group');
  statusFieldGroup?.classList.remove('u-hidden');

  // Initialize password toggles
  passwordToggleCleanup = resetAndReinitializePasswordToggles(
    [
      { input: '#employee-password', toggle: '#employee-password-toggle' },
      { input: '#employee-password-confirm', toggle: '#employee-password-confirm-toggle' },
    ],
    passwordToggleCleanup,
  );

  // Setup password strength validation
  setupPasswordStrength({
    passwordFieldId: 'employee-password',
    strengthContainerId: 'employee-password-strength-container',
    strengthBarId: 'employee-password-strength-bar',
    strengthLabelId: 'employee-password-strength-label',
    strengthTimeId: 'employee-password-strength-time',
    feedbackContainerId: 'employee-password-feedback',
    feedbackWarningId: 'employee-password-feedback-warning',
    feedbackSuggestionsId: 'employee-password-feedback-suggestions',
    getUserInputs: () => {
      const firstName = ($$id('employee-first-name') as HTMLInputElement | null)?.value ?? '';
      const lastName = ($$id('employee-last-name') as HTMLInputElement | null)?.value ?? '';
      const email = ($$id('employee-email') as HTMLInputElement | null)?.value ?? '';
      return [firstName, lastName, email].filter((v) => v !== '');
    },
  });

  // Show modal
  if (modal !== null) {
    modal.classList.add(MODAL_ACTIVE_CLASS);
  }

  // NOTE: setupFullAccessToggle removed - Employees don't have fullAccess anymore

  // SIMPLIFIED: Load only teams and restore team selection
  setTimeout(() => {
    const w = window as WindowWithEmployeeHandlers;
    void (async () => {
      // Load teams for employee select
      await w.loadTeamsForEmployeeSelect?.();

      // Restore team selections
      if (teamIds !== undefined && teamIds.length > 0) {
        console.info('[showEditEmployeeModal] Restoring team selections:', teamIds);
        setMultiSelectValues('employee-teams', teamIds);
      }

      // NOTE: Removed area/department loading and filtering - Employees only get teams
    })();
  }, 100);
}

/**
 * Close employee modal and cleanup
 * Following manage-admins closeAdminModal pattern
 */
export function closeEmployeeModal(): void {
  console.info('[closeEmployeeModal] Closing modal');

  const modal = $$id(SELECTORS.EMPLOYEE_MODAL);
  if (modal !== null) {
    modal.classList.remove(MODAL_ACTIVE_CLASS);
  }

  // Reset form to clear all fields (prevents old data from appearing in next modal)
  const form = $$id(SELECTORS.EMPLOYEE_FORM) as HTMLFormElement | null;
  if (form !== null) {
    form.reset();
  }

  // Reset custom dropdowns (form.reset() doesn't reset custom UI)
  resetCustomDropdowns();

  // Reset password strength UI to prevent cached validation state
  resetPasswordStrengthUI({
    passwordFieldId: 'employee-password',
    strengthContainerId: 'employee-password-strength-container',
    feedbackContainerId: 'employee-password-feedback',
  });

  // Cleanup password toggle event listeners
  passwordToggleCleanup?.abort();
  passwordToggleCleanup = null;
}

/**
 * Show delete confirmation modal
 * Following manage-admins pattern
 * @param employeeId - Employee ID to delete
 * @param _employeeName - Employee name (reserved for future use in confirmation message)
 */
export function showDeleteModal(employeeId: number, _employeeName: string): void {
  console.info('[showDeleteModal] Opening delete modal for employee:', employeeId);

  const deleteModal = $$id(SELECTORS.DELETE_MODAL);
  const deleteIdInput = $$id(SELECTORS.DELETE_INPUT) as HTMLInputElement | null;

  if (deleteModal !== null && deleteIdInput !== null) {
    deleteIdInput.value = String(employeeId);
    deleteModal.classList.add(MODAL_ACTIVE_CLASS);
  }
}

/**
 * Close delete confirmation modal
 */
export function closeDeleteModal(): void {
  console.info('[closeDeleteModal] Closing delete modal');

  const deleteModal = $$id(SELECTORS.DELETE_MODAL);
  if (deleteModal !== null) {
    deleteModal.classList.remove(MODAL_ACTIVE_CLASS);
  }
}

// ===== WINDOW HANDLER SETUP FUNCTIONS =====

/**
 * Setup Edit Employee Window Handler
 * Opens modal in edit mode with employee data pre-populated
 * N:M REFACTORING: Updated to pass department/team arrays
 */
export function setupEditEmployee(): void {
  const w = window as WindowWithEmployeeHandlers;
  w.editEmployee = async (id: number) => {
    const employeesManager = getEmployeesManager();
    const employee = await employeesManager?.getEmployeeDetails(id);
    if (employee === null || employee === undefined) return;

    console.info('Edit employee:', employee);
    console.info('Employee details:', {
      employeeNumber: employee.employeeNumber,
      departmentIds: employee.departmentIds,
      teamIds: employee.teamIds,
      hasFullAccess: employee.hasFullAccess,
      isActive: employee.isActive,
    });

    // Set current employee ID for update
    if (employeesManager) {
      employeesManager.currentEmployeeId = id;
    }

    // N:M REFACTORING: Pass arrays instead of single IDs
    // Support both new array format and legacy single ID format for backward compatibility
    const departmentIds =
      employee.departmentIds ?? (employee.departmentId !== undefined ? [employee.departmentId] : []);
    const teamIds = employee.teamIds ?? (employee.teamId !== undefined ? [employee.teamId] : []);

    // Show modal in edit mode with employee data
    showEditEmployeeModal(employee, departmentIds, teamIds);
  };
}

/**
 * Setup Show Employee Modal Window Handler
 * Opens modal in ADD mode with clean/reset form
 */
export function setupShowEmployeeModal(): void {
  const w = window as WindowWithEmployeeHandlers;
  w.showEmployeeModal = () => {
    // Reset current employee ID for new employee
    const employeesManager = getEmployeesManager();
    if (employeesManager) {
      employeesManager.currentEmployeeId = null;
    }
    showAddEmployeeModal();
  };
}

/**
 * Setup Hide Employee Modal Window Handler
 * Closes the employee modal
 */
export function setupHideEmployeeModal(): void {
  const w = window as WindowWithEmployeeHandlers;
  w.hideEmployeeModal = () => {
    // Reset current employee ID when closing
    const employeesManager = getEmployeesManager();
    if (employeesManager) {
      employeesManager.currentEmployeeId = null;
    }
    closeEmployeeModal();
  };
}

/**
 * Setup Close Employee Modal Window Handler
 * Alias for hideEmployeeModal for compatibility with HTML onclick handlers
 */
export function setupCloseEmployeeModal(): void {
  const w = window as WindowWithEmployeeHandlers;
  w.closeEmployeeModal = () => {
    // Reset current employee ID when closing
    const employeesManager = getEmployeesManager();
    if (employeesManager) {
      employeesManager.currentEmployeeId = null;
    }
    closeEmployeeModal();
  };
}

/**
 * Setup Delete Employee Window Handler
 * Shows delete confirmation modal
 */
export function setupDeleteEmployee(): void {
  const w = window as WindowWithEmployeeHandlers;
  w.deleteEmployee = (id: number): Promise<void> => {
    // Show delete confirmation modal instead of immediate delete
    const employeesManager = getEmployeesManager();
    const employee = employeesManager?.employees.find((e) => e.id === id);
    if (employee === undefined) {
      showErrorAlert('Mitarbeiter nicht gefunden');
      return Promise.resolve();
    }
    const employeeName = `${employee.firstName ?? ''} ${employee.lastName ?? ''}`.trim();
    showDeleteModal(id, employeeName);
    return Promise.resolve();
  };
}

/**
 * Setup Load Employees Table Window Handler
 * Triggers employee list reload
 */
export function setupLoadEmployeesTable(): void {
  const w = window as WindowWithEmployeeHandlers;
  w.loadEmployeesTable = async () => {
    console.info('[EmployeesManager] loadEmployeesTable called');
    const employeesManager = getEmployeesManager();
    await employeesManager?.loadEmployees();
  };
}

/**
 * Setup Save Employee Window Handler
 * Delegates to handleSaveEmployee from data.ts
 */
export function setupSaveEmployee(): void {
  const w = window as WindowWithEmployeeHandlers;
  w.saveEmployee = handleSaveEmployee;
}

/**
 * Setup Load Dropdowns Window Handlers
 * SIMPLIFIED: Only teams for employees (Area/Dept inherited from Team)
 */
export function setupLoadDropdowns(): void {
  const w = window as WindowWithEmployeeHandlers;
  // NOTE: loadAreasForEmployeeSelect and loadDepartmentsForEmployeeSelect removed
  // Employees only get team assignments
  w.loadTeamsForEmployeeSelect = handleLoadTeams;
}
