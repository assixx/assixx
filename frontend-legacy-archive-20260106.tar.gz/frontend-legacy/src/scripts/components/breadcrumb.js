/**
 * Breadcrumb Navigation Component
 * Business logic for breadcrumb generation and initialization
 */

// Import configuration and utilities from breadcrumb-config.js
import {
  defaultConfig,
  urlMappings,
  sectionMappings,
  generateBreadcrumbDOM,
  // Constants
  MITARBEITER_DASHBOARD_LABEL,
  BENUTZER_VERWALTEN_LABEL,
  UMFRAGEN_LABEL,
  DOKUMENTE_LABEL,
  // Icons
  ICON_POLL,
  ICON_USERS,
  ICON_FILE_ALT,
} from './breadcrumb-config.js';

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

// Breadcrumbs aus URL generieren
// Helper: Get user role from storage
function getUserRole() {
  return (
    localStorage.getItem('userRole') ||
    localStorage.getItem('role') ||
    localStorage.getItem('activeRole') ||
    sessionStorage.getItem('userRole') ||
    sessionStorage.getItem('role')
  );
}

// Helper: Get home URL based on role
function getHomeUrl(userRole) {
  const roleMap = {
    root: '/root-dashboard',
    admin: '/admin-dashboard',
    employee: '/employee-dashboard',
  };

  // Safe lookup to avoid object injection
  if (userRole === 'root') return roleMap.root;
  if (userRole === 'admin') return roleMap.admin;
  if (userRole === 'employee') return roleMap.employee;

  // Fallback: check current path
  const currentPath = window.location.pathname;
  if (currentPath.includes('root')) return roleMap.root;
  if (currentPath.includes('admin')) return roleMap.admin;
  if (currentPath.includes('employee')) return roleMap.employee;
  return '/';
}

// Helper: Find mapping safely
function findMapping(mappings, key) {
  for (const [mapKey, value] of Object.entries(mappings)) {
    if (mapKey === key) {
      return value;
    }
  }
  return null;
}

// Helper: Handle survey pages
// NOTE: No intermediate dashboard breadcrumb needed!
// "Home" already points to /admin-dashboard for admin users (via getHomeUrl())
// Adding "Admin Dashboard" would be redundant: Home > Admin Dashboard > Umfragen > Page
// Correct: Home > Umfragen > Page (where Home links to /admin-dashboard)
function handleSurveyPages(items, currentPage) {
  if (currentPage === '/survey-create' || currentPage === '/survey-results') {
    items.push({
      label: UMFRAGEN_LABEL,
      href: '/survey-admin',
      icon: ICON_POLL,
    });
    return true;
  }
  return false;
}

// Helper: Handle admin pages
// NOTE: No intermediate dashboard breadcrumb needed!
// "Home" already points to /admin-dashboard for admin users (via getHomeUrl())
function handleAdminPages(_items, currentPage) {
  // manage-admins is now standalone, not under admin-dashboard anymore
  const adminPages = ['/manage-users', '/admin-config'];
  // Return true to signal this is an admin page (prevents other handlers)
  // But do NOT add intermediate breadcrumb - Home already points to admin-dashboard
  return adminPages.includes(currentPage);
}

// Helper: Handle root pages
// NOTE: No intermediate dashboard breadcrumb needed!
// "Home" already points to /root-dashboard for root users (via getHomeUrl())
// Adding "Root Dashboard" would be redundant: Home > Root Dashboard > Page
// Correct: Home > Page (where Home links to /root-dashboard)
function handleRootPages(_items, currentPage) {
  const rootPages = ['/manage-root', '/features', '/tenant-deletion-status', '/feature-management'];
  // Return true to signal this is a root page (prevents other handlers)
  // But do NOT add intermediate breadcrumb - Home already points to root-dashboard
  return rootPages.includes(currentPage);
}

// Helper: Handle document pages
function handleDocumentPages(items, currentPage) {
  if (currentPage.includes('/documents-') || currentPage.includes('/employee-documents')) {
    items.push({
      label: DOKUMENTE_LABEL,
      href: '/documents',
      icon: ICON_FILE_ALT,
    });
    return true;
  }
  return false;
}

// Helper: Handle common pages
function handleCommonPages(items, currentPage) {
  const commonPages = ['/documents', '/blackboard', '/chat', '/shifts'];
  if (commonPages.includes(currentPage)) {
    const userRole = getUserRole();
    // Only add employee dashboard for employees, not for admin/root
    if (userRole === 'employee') {
      items.push({
        label: MITARBEITER_DASHBOARD_LABEL,
        href: '/employee-dashboard',
        icon: 'fa-user',
      });
    }
    // Admin and root go directly to the page without intermediate dashboard
    return true;
  }
  return false;
}

/**
 * Add home breadcrumb item
 */
function addHomeBreadcrumb(items) {
  const userRole = getUserRole();
  const homeHref = getHomeUrl(userRole);

  items.push({
    label: defaultConfig.homeLabel,
    href: homeHref,
    icon: defaultConfig.homeIcon,
  });
}

/**
 * Handle archived employees breadcrumb
 * NOTE: No dashboard breadcrumb - Home already points to dashboard
 */
function handleArchivedEmployees(items) {
  items.push({
    label: BENUTZER_VERWALTEN_LABEL,
    href: '/manage-users',
    icon: ICON_USERS,
  });
}

/**
 * Handle department groups breadcrumb
 * Hierarchy: Home > Abteilungen > Abteilungsgruppen
 */
function handleDepartmentGroups(items) {
  items.push({
    label: 'Abteilungen',
    href: '/manage-departments',
    icon: 'fa-building',
  });
}

/**
 * Handle account settings breadcrumb
 * NOTE: No dashboard breadcrumb - Home already points to dashboard
 */
function handleAccountSettings(_items) {
  // No intermediate breadcrumb needed - Home links to dashboard
  return;
}

/**
 * Process special page handlers
 */
function processSpecialHandlers(items, currentPage) {
  return (
    handleSurveyPages(items, currentPage) ||
    handleAdminPages(items, currentPage) ||
    handleRootPages(items, currentPage) ||
    handleCommonPages(items, currentPage) ||
    handleDocumentPages(items, currentPage)
  );
}

/**
 * Process special case pages
 */
function processSpecialCases(items, currentPage) {
  const isArchivedEmployees = currentPage === '/archived-employees';
  const isDepartmentGroups = currentPage === '/manage-department-groups';
  const isAccountRelated = ['/account-settings', '/storage-upgrade'].includes(currentPage);

  if (isArchivedEmployees) {
    handleArchivedEmployees(items);
    return true;
  }

  if (isDepartmentGroups) {
    handleDepartmentGroups(items);
    return true;
  }

  if (isAccountRelated) {
    handleAccountSettings(items);
    return true;
  }

  return false;
}

/**
 * Add section breadcrumb for admin dashboard
 */
function addSectionBreadcrumb(items, section) {
  const sectionMapping = findMapping(sectionMappings, section);

  if (sectionMapping) {
    items.push({
      ...sectionMapping,
      current: true,
    });
  } else {
    items.push({
      label: section.charAt(0).toUpperCase() + section.slice(1).replace(/[^\s\w-]/g, ''),
      current: true,
    });
  }
}

/**
 * Add current page breadcrumb
 */
function addCurrentPageBreadcrumb(items, currentPage, mapping, section) {
  const isAdminDashboard = currentPage === '/admin-dashboard';

  if (isAdminDashboard && section) {
    addSectionBreadcrumb(items, section);
    return;
  }

  items.push({
    ...mapping,
    current: true,
  });
}

/**
 * Add fallback breadcrumb for unmapped pages
 */
function addFallbackBreadcrumb(items, currentPage) {
  const pageName = currentPage
    .split('/')
    .pop()
    .replace(/-/g, ' ')
    .replace(/[^\s0-9A-Za-z]/g, '');

  items.push({
    label: pageName.charAt(0).toUpperCase() + pageName.slice(1),
    current: true,
  });
}

/**
 * Check if current page is a root page
 */
function isRootPage(currentPage) {
  return currentPage === '/' || currentPage === '/index' || currentPage === '';
}

// Main function
function generateBreadcrumbsFromURL() {
  const path = window.location.pathname;
  const urlParams = new URLSearchParams(window.location.search);
  const section = urlParams.get('section');
  const items = [];

  addHomeBreadcrumb(items);

  const currentPage = path.replace(/\.html$/, '');

  if (isRootPage(currentPage)) {
    return items;
  }

  const mapping = findMapping(urlMappings, currentPage);

  if (!mapping) {
    addFallbackBreadcrumb(items, currentPage);
    return items;
  }

  const handledBySpecial = processSpecialHandlers(items, currentPage);

  if (!handledBySpecial) {
    processSpecialCases(items, currentPage);
  }

  addCurrentPageBreadcrumb(items, currentPage, mapping, section);

  return items;
}

// Hauptfunktion zum Initialisieren der Breadcrumbs
export function initBreadcrumb(customItems = null, customConfig = {}) {
  // Styles are handled by Design System (breadcrumb.css)

  // Konfiguration zusammenführen
  const config = { ...defaultConfig, ...customConfig };

  // Items bestimmen (custom oder auto-generated)
  const items = customItems || generateBreadcrumbsFromURL();

  // Container finden
  const container = document.querySelector(config.container);
  if (!container) {
    console.warn(`Breadcrumb container '${config.container}' nicht gefunden`);
    return;
  }

  // DOM sicher generieren und einfügen
  const breadcrumbElement = generateBreadcrumbDOM(items, config);
  container.innerHTML = '';
  container.append(breadcrumbElement);

  // Event für debugging
  console.info('Breadcrumb initialisiert:', items);
}

// Auto-Init wenn DOM geladen
document.addEventListener('DOMContentLoaded', () => {
  // Nur auto-init wenn Container existiert und leer ist
  const container = document.querySelector(defaultConfig.container);

  if (container && container.innerHTML.trim() === '') {
    initBreadcrumb();
  }
});

// Für direkten Import
export default initBreadcrumb;
