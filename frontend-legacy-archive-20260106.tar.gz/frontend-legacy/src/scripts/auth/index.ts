/**
 * Authentication utilities for Assixx
 */

import type { User } from '../../types/api.types';
import { apiClient, ApiError } from '../../utils/api-client';
import { tokenManager } from '../../utils/token-manager';
import { getUserRole, setUserRole, clearUserRole, getActiveRole } from '../../utils/auth-helpers';
import { parseJwt } from '../../utils/jwt-utils';
import { SessionManager } from '../utils/session-manager';

// Extend window for auth functions
declare global {
  interface Window {
    getAuthToken: typeof getAuthToken;
    setAuthToken: typeof setAuthToken;
    removeAuthToken: typeof removeAuthToken;
    isAuthenticated: typeof isAuthenticated;
    fetchWithAuth: typeof fetchWithAuth;
    loadUserInfo: typeof loadUserInfo;
    login: typeof login;
    logout: typeof logout;
    showSuccess: typeof showSuccess;
    showError: typeof showError;
    showInfo: typeof showInfo;
    parseJwt: typeof parseJwt;
  }
}

// Get authentication token from localStorage (compatible with existing system)
export function getAuthToken(): string | null {
  // Always use v2 accessToken
  return localStorage.getItem('accessToken');
}

// Get current user's ID
export function getUserId(): number | null {
  const userStr = localStorage.getItem('user');
  if (userStr === null || userStr === '') return null;

  try {
    const user = JSON.parse(userStr) as { id?: number };
    return user.id ?? null;
  } catch {
    return null;
  }
}

// Set authentication token
export function setAuthToken(token: string, refreshToken?: string): void {
  // For v2, store both access and refresh tokens
  localStorage.setItem('accessToken', token);
  if (refreshToken !== undefined && refreshToken.length > 0) {
    localStorage.setItem('refreshToken', refreshToken);
  }
  // Also store in old format for compatibility
  localStorage.setItem('token', token);

  // Set cookie for server-side page protection (temporary compatibility)
  document.cookie = `token=${token}; path=/; max-age=${7 * 24 * 60 * 60}; SameSite=Lax`;
}

// Remove authentication token
export function removeAuthToken(): void {
  // ===========================================
  // AUTH TOKENS (CRITICAL - must be cleared)
  // ===========================================
  localStorage.removeItem('accessToken');
  localStorage.removeItem('refreshToken');
  localStorage.removeItem('tokenReceivedAt'); // Clock skew fix timestamp
  localStorage.removeItem('token'); // Legacy v1 token
  localStorage.removeItem('authToken'); // Legacy v1 token

  // ===========================================
  // USER DATA
  // ===========================================
  localStorage.removeItem('user');
  localStorage.removeItem('role'); // Legacy role
  clearUserRole(); // Clears userRole + activeRole

  // ===========================================
  // COOKIE CLEARING (legacy compatibility)
  // ===========================================
  document.cookie = 'token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 UTC; SameSite=Lax';
}

// Check if user is authenticated
export function isAuthenticated(): boolean {
  const token = getAuthToken();
  if (token === null || token.length === 0) {
    return false;
  }

  // Check if token is expired
  const payload = parseJwt(token);
  if (payload?.exp === undefined) {
    return false;
  }

  // Check expiration (exp is in seconds, Date.now() is in milliseconds)
  const now = Date.now() / 1000;
  if (payload.exp < now) {
    console.info('[AUTH] Token expired, clearing auth data');
    removeAuthToken();
    return false;
  }

  return true;
}

// Re-export parseJwt for backward compatibility
export { parseJwt } from '../../utils/jwt-utils';

// Helper: Get redirect URL based on user role
function getRoleBasedRedirectUrl(): string {
  const userRole = getUserRole();
  switch (userRole) {
    case 'employee':
      return '/employee-dashboard';
    case 'admin':
      return '/admin-dashboard';
    case 'root':
      return '/root-dashboard';
    default:
      return '/login.html';
  }
}

// Helper: Handle unauthorized error
function handleUnauthorized(): never {
  removeAuthToken();
  window.location.assign('/login');
  throw new Error('Unauthorized');
}

// Helper: Handle forbidden error
function handleForbidden(): never {
  const redirectUrl = getRoleBasedRedirectUrl();
  console.warn(`Access forbidden. Redirecting to ${redirectUrl}`);
  window.location.assign(redirectUrl);
  throw new Error('Forbidden - insufficient permissions');
}

// Helper: Make V2 API request
async function makeV2ApiRequest(path: string, method: string, body: string | null | undefined): Promise<unknown> {
  switch (method.toUpperCase()) {
    case 'GET':
      return await apiClient.get(path);
    case 'POST': {
      const postBody = body !== undefined && body !== null ? (JSON.parse(body) as unknown) : undefined;
      return await apiClient.post(path, postBody);
    }
    case 'PUT': {
      const putBody = body !== undefined && body !== null ? (JSON.parse(body) as unknown) : undefined;
      return await apiClient.put(path, putBody);
    }
    case 'DELETE': {
      const deleteBody = body !== undefined && body !== null ? (JSON.parse(body) as unknown) : undefined;
      return await apiClient.delete(path, deleteBody);
    }
    default:
      throw new Error(`Unsupported method: ${method}`);
  }
}

// Helper: Handle V2 API request with error handling
async function fetchWithV2Api(url: string, options: RequestInit): Promise<Response> {
  try {
    const urlObj = new URL(url, window.location.origin);
    const path = urlObj.pathname.replace('/api/v2', '').replace('/api', '');
    const method = options.method ?? 'GET';

    const response = await makeV2ApiRequest(path, method, options.body as string | null | undefined);

    return new Response(JSON.stringify(response), {
      status: 200,
      statusText: 'OK',
      headers: new Headers({ 'Content-Type': 'application/json' }),
    });
  } catch (error) {
    if (error instanceof ApiError) {
      if (error.status === 401) handleUnauthorized();
      if (error.status === 403) handleForbidden();

      return new Response(JSON.stringify({ error: error.message }), {
        status: error.status,
        statusText: error.message,
        headers: new Headers({ 'Content-Type': 'application/json' }),
      });
    }
    throw error;
  }
}

// Helper: Handle V1 API request
// Fetch with authentication
export async function fetchWithAuth(url: string, options: RequestInit = {}): Promise<Response> {
  const token = getAuthToken();

  if (token === null || token.length === 0) {
    window.location.href = '/login';
    throw new Error('No authentication token');
  }

  return await fetchWithV2Api(url, options);
}

// Load user information
// Cache for user profile to prevent multiple API calls
let userProfileCache: { data: User | null; timestamp: number } = { data: null, timestamp: 0 };
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

// Promise cache to prevent concurrent requests
let profileLoadingPromise: Promise<User> | null = null;

// Helper: Check if cache is valid
function isCacheValid(): boolean {
  return userProfileCache.data !== null && Date.now() - userProfileCache.timestamp < CACHE_DURATION;
}

// Helper: Convert API response to User
// Helper: Update DOM elements with user info
function updateUserDisplay(user: User): void {
  const userName = document.querySelector('#userName') ?? document.querySelector('#user-name');
  if (userName !== null) {
    interface UserWithBothFormats extends User {
      firstName?: string;
      lastName?: string;
    }
    const userWithBoth = user as UserWithBothFormats;
    const firstName = userWithBoth.firstName ?? userWithBoth.firstName ?? userWithBoth.username;
    const lastName = userWithBoth.lastName ?? userWithBoth.lastName ?? '';
    const displayName = `${firstName} ${lastName}`.trim();
    if (userName.textContent !== displayName) {
      userName.textContent = displayName;
    }
  }

  const userRole = document.querySelector('#userRole');
  if (userRole) {
    userRole.textContent = user.role;
  }
}

// Helper: Get fallback user on error
function getFallbackUser(): User {
  const userName = document.querySelector('#userName');
  if (userName) userName.textContent = 'Benutzer';

  const userRole = document.querySelector('#userRole');
  if (userRole) userRole.textContent = localStorage.getItem('role') ?? 'Benutzer';

  return {
    id: 0,
    username: 'Benutzer',
    email: '',
    firstName: 'Benutzer',
    role: (localStorage.getItem('role') ?? 'admin') as User['role'],
    tenantId: 0,
    isActive: 1, // Active status
    createdAt: '',
    updatedAt: '',
  } as User;
}

// Helper: Fetch user profile from API
async function fetchUserProfile(): Promise<User> {
  // Use apiClient for v2 API (already returns User object)
  console.info('loadUserInfo: Using apiClient for v2 API');
  const user = await apiClient.get<User>('/users/me');
  console.info('loadUserInfo: Response data:', user);

  updateUserDisplay(user);
  userProfileCache = { data: user, timestamp: Date.now() };
  console.info('loadUserInfo: Profile cached for', CACHE_DURATION / 1000, 'seconds');

  return user;
}

// Legacy v1 code removed - always using v2 API

// Legacy v1 code removed - always using v2 API

export async function loadUserInfo(forceRefresh: boolean = false): Promise<User> {
  try {
    // Invalidate cache if force refresh requested
    if (forceRefresh) {
      userProfileCache = { data: null, timestamp: 0 };
    }

    if (isCacheValid() && userProfileCache.data) {
      console.info('loadUserInfo: Returning cached profile data');
      return userProfileCache.data;
    }

    if (profileLoadingPromise) {
      console.info('loadUserInfo: Waiting for existing profile request...');
      return await profileLoadingPromise;
    }

    console.info('loadUserInfo: Attempting to fetch user profile...');

    // Create and store promise atomically
    const promise = fetchUserProfile().finally(() => {
      // Clear the promise when done, regardless of success or failure
      if (profileLoadingPromise === promise) {
        profileLoadingPromise = null;
      }
    });

    profileLoadingPromise = promise;
    return await promise;
  } catch (error) {
    console.error('Error loading user info:', error);
    return getFallbackUser();
  }
}

// Logout function
export async function logout(): Promise<void> {
  const token = getAuthToken();

  // ===========================================
  // STEP 1: Call logout API (revokes DB tokens)
  // ===========================================
  if (token !== null && token.length > 0) {
    try {
      await apiClient.post('/auth/logout', {});
    } catch (error) {
      console.error('Error logging logout:', error);
      // Continue with logout even if API call fails
    }
  }

  // ===========================================
  // STEP 2: Clear auth tokens (via removeAuthToken)
  // ===========================================
  removeAuthToken();

  // ===========================================
  // STEP 3: Clear session data
  // ===========================================
  localStorage.removeItem('tenantId');
  localStorage.removeItem('lastActivity');

  // ===========================================
  // STEP 4: Clear fingerprint data
  // ===========================================
  localStorage.removeItem('browserFingerprint');
  localStorage.removeItem('fingerprintTimestamp');

  // ===========================================
  // STEP 5: Clear UI state (clean slate on next login)
  // ===========================================
  localStorage.removeItem('sidebarCollapsed');
  localStorage.removeItem('openSubmenu');
  localStorage.removeItem('activeNavigation');
  localStorage.removeItem('profilePictureCache');

  // ===========================================
  // STEP 6: Clear feature-specific state
  // ===========================================
  localStorage.removeItem('lastKvpClickTimestamp');
  localStorage.removeItem('lastKnownKvpCount');
  localStorage.removeItem('shifts_context');
  localStorage.removeItem('rateLimitTimestamp');

  // ===========================================
  // STEP 7: Clear in-memory caches
  // ===========================================
  userProfileCache = { data: null, timestamp: 0 };
  profileLoadingPromise = null;

  // ===========================================
  // STEP 8: TokenManager handles timer stop + redirect
  // ===========================================
  tokenManager.clearTokens('logout');
}

// Helper: Login with V2 API
async function loginV2(email: string, password: string): Promise<{ success: boolean; message?: string }> {
  try {
    const response = await apiClient.post<{
      accessToken?: string;
      refreshToken?: string;
      user?: User;
    }>('/auth/login', { email, password });

    if (
      response.accessToken !== undefined &&
      response.accessToken.length > 0 &&
      response.refreshToken !== undefined &&
      response.refreshToken.length > 0
    ) {
      // Set tokens via TokenManager (handles timer restart)
      tokenManager.setTokens(response.accessToken, response.refreshToken);
      // Also call setAuthToken for backward compatibility (cookie + legacy 'token' localStorage)
      setAuthToken(response.accessToken, response.refreshToken);

      if (response.user) {
        localStorage.setItem('user', JSON.stringify(response.user));
        setUserRole(response.user.role);
      }

      return { success: true };
    }
    return { success: false, message: 'Invalid response format' };
  } catch (error) {
    if (error instanceof ApiError) {
      return { success: false, message: error.message };
    }
    return { success: false, message: 'Login failed' };
  }
}

// Helper: Login with V1 API
// Login function
export async function login(email: string, password: string): Promise<{ success: boolean; message?: string }> {
  try {
    return await loginV2(email, password);
  } catch (error) {
    console.error('Login error:', error);
    return { success: false, message: 'Network error' };
  }
}

// Show success message
export function showSuccess(message: string): void {
  // Simple console log for now, can be enhanced with toast notifications
  console.info(`✅ ${message}`);
}

// Show error message
export function showError(message: string): void {
  // Simple console log for now, can be enhanced with toast notifications
  console.error(`❌ ${message}`);
}

// Show info message
export function showInfo(message: string): void {
  // Simple console log for now, can be enhanced with toast notifications
  console.info(`ℹ️ ${message}`);
}

// Helper: Check if should redirect to login
function shouldRedirectToLogin(): boolean {
  return !isAuthenticated() && !window.location.pathname.includes('login');
}

// Helper: Check if on authenticated page
function isOnAuthenticatedPage(): boolean {
  return isAuthenticated() && !window.location.pathname.includes('login');
}

// Helper: Initialize session manager
function initializeSessionManager(): void {
  // Initialize SessionManager singleton (starts inactivity timer via side-effects)
  SessionManager.getInstance();
  console.info('[AUTH] Session manager initialized');
}

// Helper: Initialize authenticated user
async function initializeAuthenticatedUser(): Promise<void> {
  console.info('[AUTH] Loading user info...');
  try {
    await loadUserInfo();
  } catch (error: unknown) {
    console.error('Failed to load user info:', error);
  }

  initializeSessionManager();
  // NOTE: enforcePageAccess() is already called by UnifiedNavigation.setupInitialState()
  // Removed duplicate call here to avoid redundant access checks
}

// Initialize authentication on page load
document.addEventListener('DOMContentLoaded', () => {
  // Use IIFE to handle async operations
  void (async () => {
    const token = getAuthToken();
    const userRole = getUserRole();
    const activeRole = getActiveRole();

    console.info('[AUTH] Initialization:', {
      token: token !== null && token.length > 0,
      userRole,
      activeRole,
      path: window.location.pathname,
      isEmployeeDashboard: window.location.pathname.includes('employee-dashboard'),
    });

    if (shouldRedirectToLogin()) {
      console.info('[AUTH] No authentication token found, redirecting to login');
      window.location.href = '/login';
      return;
    }

    if (isOnAuthenticatedPage()) {
      await initializeAuthenticatedUser();
    }
  })();
});

// Export functions to window for backwards compatibility
if (typeof window !== 'undefined') {
  // These are already declared in global.d.ts
  window.getAuthToken = getAuthToken;
  window.setAuthToken = setAuthToken;
  window.removeAuthToken = removeAuthToken;
  window.isAuthenticated = isAuthenticated;
  window.fetchWithAuth = fetchWithAuth;
  window.loadUserInfo = loadUserInfo;
  window.login = login;
  window.logout = logout;
  window.showSuccess = showSuccess;
  window.showError = showError;
  window.showInfo = showInfo;
  window.parseJwt = parseJwt;
}
