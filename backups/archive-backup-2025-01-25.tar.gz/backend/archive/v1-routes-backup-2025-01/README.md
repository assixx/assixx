# V1 Routes Archive

**Archived:** 2025-10-25
**Reason:** Migrated to V2 API (no fallback)
**Dependencies:** All removed, safe to delete
**Last commit before archive:** See git log

## What was archived

All Express route handlers from the V1 API including:

- admin.ts
- admin-permissions.ts
- areas.ts
- auth.ts / auth.routes.ts
- availability.ts
- blackboard.ts
- calendar.ts
- chat.ts
- department-groups.ts
- departments.ts
- documents.ts
- employee.ts
- features.ts
- index.ts
- kvp.ts / kvp.routes.ts
- logs.ts
- machines.ts
- payroll.ts
- plans.ts
- root.ts
- shifts.ts
- storage.ts
- survey.ts
- teams.ts
- users.ts

## Migration Status

✅ All V1 routes have been migrated to V2
✅ V2 API is now standalone without V1 fallback
✅ All dependencies to v1/logs removed (using rootLog.create() instead)
✅ TypeScript compiles without v1 dependencies

## Known Issues in Archived Code

These errors existed before archiving:

- blackboard.ts: Type comparison errors (lines 185, 195)
- kvp.routes.ts: AuthenticatedRequest type not found
- kvp.ts: Type mismatch in request parameters
- machines.ts: Unused Request import

## Can this be deleted?

**Yes**, after confirming:

1. V2 API works in production
2. No rollback to V1 needed
3. Archive backup is committed to git

## Restoration (if needed)

```bash
# Copy back from archive
cp backend/archive/v1-routes-backup-2025-01/* backend/src/routes/v1/

# Restore v1 logs dependency in auth.controller
# Add back: import { createLog } from '../../v1/logs';
```

---

**Note:** This is a clean migration. V1 code was functional but deprecated in favor of:

- Better TypeScript typing (Zod validation)
- Consistent error handling
- Improved request/response patterns
- Proper separation of concerns (Controller/Service pattern)
