/**
 * Authentication Routes
 * Uses controller pattern for cleaner code
 */
import express, { Router } from 'express';
import { body } from 'express-validator';

import authController from '../../controllers/auth.controller';
import { security } from '../../middleware/security';
import {
  attachCSRFToken,
  generateCSRFTokenMiddleware,
  strictAuthLimiter,
} from '../../middleware/security-enhanced';
import { createValidation } from '../../middleware/validation';
import { validateSignup } from '../../middleware/validators';
import { successResponse } from '../../types/response.types';
import { typed } from '../../utils/routeHandlers';

const router: Router = express.Router();

// Debug logging
console.info('[DEBUG] Auth routes loading...');

// Request body interfaces
interface LoginBody {
  username?: string;
  email?: string;
  password: string;
}

interface RegisterBody {
  username: string;
  email: string;
  password: string;
  first_name?: string;
  last_name?: string;
  phone?: string;
}

interface ValidateFingerprintBody {
  fingerprint: string;
}

// Validation schemas
const loginValidation = createValidation([
  body('password').notEmpty().withMessage('Passwort ist erforderlich'),
  body('username').optional().trim(),
  body('email').optional().isEmail().normalizeEmail(),
]);

const validateFingerprintValidation = createValidation([
  body('fingerprint').notEmpty().trim().withMessage('Fingerprint ist erforderlich'),
]);

// Public routes with enhanced rate limiting and validation
router.post(
  '/login',
  strictAuthLimiter,
  ...security.auth(loginValidation),
  typed.body<LoginBody>(async (req, res) => {
    console.info('[DEBUG] /api/auth/login endpoint hit');
    await authController.login(req, res);
  }),
);
router.post(
  '/register',
  strictAuthLimiter,
  ...validateSignup,
  typed.body<RegisterBody>(async (req, res) => {
    await authController.register(req, res);
  }),
);
router.get(
  '/logout',
  ...security.user(),
  typed.auth(async (req, res) => {
    await authController.logout(req, res);
  }),
);
router.post(
  '/logout',
  ...security.user(),
  typed.auth(async (req, res) => {
    await authController.logout(req, res);
  }),
); // Support both GET and POST

// CSRF Token endpoint
router.get(
  '/csrf-token',
  generateCSRFTokenMiddleware,
  attachCSRFToken,
  typed.public((_req, res) => {
    res.json(
      successResponse(
        {
          csrfToken: res.locals.csrfToken as string,
        },
        'CSRF token generated successfully',
      ),
    );
  }),
);

// Protected routes
router.get(
  '/check',
  ...security.user(),
  typed.auth((req, res) => {
    authController.checkAuth(req, res);
  }),
);
router.get(
  '/user',
  ...security.user(),
  typed.auth(async (req, res) => {
    await authController.getUserProfile(req, res);
  }),
);
router.get(
  '/me',
  ...security.user(),
  typed.auth(async (req, res) => {
    await authController.getUserProfile(req, res);
  }),
);

// Session validation endpoints
router.get(
  '/validate',
  ...security.user(),
  typed.auth(async (req, res) => {
    await authController.validateToken(req, res);
  }),
);
router.post(
  '/validate-fingerprint',
  ...security.user(validateFingerprintValidation),
  typed.body<ValidateFingerprintBody>(async (req, res) => {
    await authController.validateFingerprint(req, res);
  }),
);

// Token refresh endpoint
router.post(
  '/refresh',
  createValidation([body('refreshToken').notEmpty().withMessage('Refresh token ist erforderlich')]),
  typed.body<{ refreshToken: string }>(async (req, res) => {
    await authController.refreshToken(req, res);
  }),
);

// Password reset routes
router.post(
  '/forgot-password',
  strictAuthLimiter,
  createValidation([
    body('email').isEmail().normalizeEmail().withMessage('Gültige E-Mail-Adresse erforderlich'),
  ]),
  typed.body<{ email: string }>((req, res) => {
    authController.forgotPassword(req, res);
  }),
);

router.post(
  '/reset-password',
  strictAuthLimiter,
  createValidation([
    body('token').notEmpty().withMessage('Token ist erforderlich'),
    body('newPassword')
      .isLength({ min: 8 })
      .withMessage('Passwort muss mindestens 8 Zeichen lang sein'),
  ]),
  typed.body<{ token: string; newPassword: string }>((req, res) => {
    authController.resetPassword(req, res);
  }),
);

export default router;

// CommonJS compatibility
